<?php

// Written at Louisiana State University
$plugin->version = 2014022713;
$plugin->requires = 2012120304;
$plugin->release = "v1.3.2";
